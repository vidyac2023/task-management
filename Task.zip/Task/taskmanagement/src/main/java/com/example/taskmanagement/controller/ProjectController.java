package com.example.taskmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.taskmanagement.dto.CodeDTO;
import com.example.taskmanagement.dto.NewProgramDTO;
import com.example.taskmanagement.resources.ProjectListResource;
import com.example.taskmanagement.service.ProjectService;
import com.example.taskmanagement.service.UserService;

import io.swagger.annotations.Api;

@RestController
@Api(value = "API to create projects by admin",
description = "This API provides the capability to create proejct by admin", produces = "application/json")
public class ProjectController {
    
  @Autowired
  private ProjectService service;
  
  @Autowired
  private UserService userService;
  
  @PostMapping("/createProgram/{uid}")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<Boolean> createProgram(@PathVariable("uid") Long uid, @RequestBody NewProgramDTO newProgramDto) {
    service.createProgram(newProgramDto, uid);
    return new ResponseEntity<Boolean>(true,HttpStatus.OK);
  }
  
  @GetMapping("/getAllProgram")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<ProjectListResource> getAllProgram() {
    return new ResponseEntity<ProjectListResource>(service.getAll(), HttpStatus.OK);
  }
  
  @GetMapping("/getAllProgramByAdmin/{id}")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<ProjectListResource> getAllProgramByAdmin(@PathVariable("id") Long id) {
	  ProjectListResource dto = service.getAllByAdmin(id);
    return new ResponseEntity<ProjectListResource>(dto, HttpStatus.OK);
  }
  
  @GetMapping("/getAllProgramByUser/{uid}")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<ProjectListResource> getAllProgramByUser(@PathVariable("uid") Long uid) {
	  ProjectListResource dto = new ProjectListResource();
    dto.setProgramList(userService.getAllProgramByUser(uid));
    return new ResponseEntity<ProjectListResource>(dto, HttpStatus.OK);
  }
  
  @PostMapping("/enterPrg")
  @PreAuthorize("hasRole('ADMIN')")
  public ResponseEntity<Boolean> enterProgram(@RequestBody CodeDTO code) {
    service.addUser(code.getUid(), code.getCode());
    return new ResponseEntity<Boolean>(true,HttpStatus.OK);
  }
}
