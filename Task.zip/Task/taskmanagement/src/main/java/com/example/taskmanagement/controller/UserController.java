package com.example.taskmanagement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.taskmanagement.dto.UserDTO;
import com.example.taskmanagement.resources.UserListResource;
import com.example.taskmanagement.resources.UserResource;
import com.example.taskmanagement.service.UserService;

import io.swagger.annotations.Api;

@RestController
@Api(value = "API to search Users",
description = "This API provides the capability to search User details", produces = "application/json")
public class UserController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	 @Autowired
	  private UserService service;
	 
	 @PostMapping("/createUser/{uid}")
	  @PreAuthorize("hasRole('ADMIN')")
	  public ResponseEntity<Boolean> createProgram(@PathVariable("uid") Long uid, @RequestBody UserDTO newProgramDto) {
	    service.createProgram(newProgramDto, uid);
	    return new ResponseEntity<Boolean>(true,HttpStatus.OK);
	  }
	
	  @GetMapping("/getAllUser")
	  @PreAuthorize("hasRole('ADMIN')")
	  public ResponseEntity<UserListResource> getAllUser() {
	    UserListResource ulr = new UserListResource();
	    ulr.setUserList(service.getAllUser());
	    return new ResponseEntity<UserListResource>(ulr, HttpStatus.OK);
	  }
	  
	  @GetMapping("/getAllUser/{pid}")
	  @PreAuthorize("hasRole('ADMIN')")
	  public ResponseEntity<UserListResource> getAllUser(@PathVariable("pid") Long pid) {
	    UserListResource ulr = new UserListResource();
	    ulr.setUserList(service.getAllUserByProgram(pid));
	    return new ResponseEntity<UserListResource>(ulr, HttpStatus.OK);
	  }

	  @GetMapping("/getUser/{uid}")
	  @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	  public ResponseEntity<UserResource> getUserById(@PathVariable("uid") Long uid) {
	    UserResource ur = new UserResource();
	    BeanUtils.copyProperties(service.getUser(uid), ur);
	    return new ResponseEntity<UserResource>(ur, HttpStatus.OK);
	  }

}
