package com.example.taskmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.taskmanagement.dto.NewProgramDTO;
import com.example.taskmanagement.entities.Project;
import com.example.taskmanagement.entities.Users;
import com.example.taskmanagement.repository.ProjectRepository;
import com.example.taskmanagement.repository.UserRepository;
import com.example.taskmanagement.resources.ProjectListResource;
import com.example.taskmanagement.resources.ProjectResource;


@Service
public class ProjectService {

  @Autowired
  private UserRepository userRepository;
  @Autowired
  private ProjectRepository programRepository;

  
  public void addUser(long uid, String code) {
	  Users user = userRepository.findById(uid).get();
	  Project p = programRepository.findById(uid).get();
      List<Users> users = p.getUsers();
      users.add(user);
      p.setUsers(users);
      programRepository.save(p);
  
  }

  public long createProgram(NewProgramDTO newProgramDto, long admin) {
    Project program = new Project();
    program.setId(newProgramDto.getId());
    program.setName(newProgramDto.getName());
    program.setDescription(newProgramDto.getDescription());
    program.setAdmin(admin);
    Users user = userRepository.findById(admin).get();
    List<Users> userList = new ArrayList<Users>();
    userList.add(user);
    program.setUsers(userList);
    Project savedProgram = programRepository.save(program);

   
    long[] users = newProgramDto.getUsers();
  
    
    return savedProgram.getId();
  }
  
 
  
  public ProjectListResource getAll() {
	  ProjectListResource list = new ProjectListResource();
    list.setProgramList( (List<ProjectResource>) programRepository.findAll().stream().map(p -> new ProjectResource(p)).collect(Collectors.toList()));
    return list;
  }
  
  public ProjectListResource getAllByAdmin(long id) {
	  ProjectListResource list = new ProjectListResource();
    list.setProgramList( (List<ProjectResource>) programRepository.findByAdmin(id).stream().map(p -> new ProjectResource(p)).collect(Collectors.toList()));
    return list;
  }
}
