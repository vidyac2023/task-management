package com.example.taskmanagement.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.taskmanagement.dto.UserDTO;
import com.example.taskmanagement.entities.Users;
import com.example.taskmanagement.repository.ProjectRepository;
import com.example.taskmanagement.repository.UserRepository;
import com.example.taskmanagement.resources.ProjectResource;
import com.example.taskmanagement.resources.UserResource;


@Service
public class UserService {
  @Autowired
  private ProjectRepository programRepository;
  @Autowired
  private UserRepository userRepository;
 
  public List<UserResource> getAllUser() {
    return (List<UserResource>) userRepository.findAll()
                                .stream()
                                .map(user -> new UserResource(user))
                                .collect(Collectors.toList());
  }
  
  public List<UserResource> getAllUserByProgram(long programId) {
    List<UserResource> users = programRepository.findById(programId)
                                .get()
                                .getUsers()
                                .stream()
                                .map(user -> new UserResource(user))
                                .collect(Collectors.toList());
    return users;
  }
  
  public List<ProjectResource> getAllProgramByUser(long uid) {
    return userRepository.findProgramById(uid)
                                .stream()
                                .map(program -> new ProjectResource(program))
                                .collect(Collectors.toList());
  }
  
  public Users getUser(long id) {
    return userRepository.findById(id).get();
  }

public void createProgram(UserDTO newProgramDto, Long uid) {
	// TODO Auto-generated method stub
	
}
}
