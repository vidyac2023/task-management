package com.example.taskmanagement.dto;

import java.util.List;

import com.example.taskmanagement.entities.Project;

public class ProgramListDTO {
  private List<Project> programList;

  public List<Project> getProgramList() {
    return programList;
  }

  public void setProgramList(List<Project> programList) {
    this.programList = programList;
  }
}
