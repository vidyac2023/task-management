package com.example.taskmanagement.entities;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}