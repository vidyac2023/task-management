package com.example.taskmanagement.resources;

import java.util.List;

public class ProjectListResource {

  private List<ProjectResource> programList;

  public List<ProjectResource> getProgramList() {
    return programList;
  }

  public void setProgramList(List<ProjectResource> programList) {
    this.programList = programList;
  }
  
}
